<?php
require_once 'config/config.php';
require_once 'includes/functions.php';
require_once 'includes/check_permissions.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$wedding_id = $_SESSION['wedding_id'] ?? 1;

// Verifica i permessi per la gestione del budget
if (!canManageBudget()) {
    header('Location: dashboard.php');
    exit();
}

// Gestione delle azioni
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'update':
                if (canManageBudget()) {
                    $importo_totale = floatval($_POST['importo_totale']);
                    
                    // Verifica se esiste già un record per questo matrimonio
                    $check = $conn->prepare("SELECT ID_Budget FROM BUDGET WHERE ID_Matrimonio = ?");
                    $check->bind_param("i", $wedding_id);
                    $check->execute();
                    $result = $check->get_result();
                    
                    if ($result->num_rows > 0) {
                        // Aggiorna il record esistente
                        $stmt = $conn->prepare("UPDATE BUDGET SET importo_totale = ? WHERE ID_Matrimonio = ?");
                        $stmt->bind_param("di", $importo_totale, $wedding_id);
                    } else {
                        // altrimenti inserisce un nuovo record
                        $stmt = $conn->prepare("INSERT INTO BUDGET (importo_totale, ID_Matrimonio) VALUES (?, ?)");
                        $stmt->bind_param("di", $importo_totale, $wedding_id);
                    }
                    $stmt->execute();
                }
                break;

            case 'add_spesa':
                if (canManageBudget()) {
                    $descrizione = sanitizeInput($_POST['descrizione']);
                    $importo = floatval($_POST['importo']);
                    $data = $_POST['data'];
                    
                    // Recupera l'ID del budget
                    $stmt = $conn->prepare("SELECT ID_Budget FROM BUDGET WHERE ID_Matrimonio = ?");
                    $stmt->bind_param("i", $wedding_id);
                    $stmt->execute();
                    $budget_id = $stmt->get_result()->fetch_assoc()['ID_Budget'];
                    
                    // Inserisci la spesa
                    $stmt = $conn->prepare("INSERT INTO SPESA (descrizione, importo, data, ID_Budget) VALUES (?, ?, ?, ?)");
                    $stmt->bind_param("sdsi", $descrizione, $importo, $data, $budget_id);
                    $stmt->execute();
                }
                break;

                case 'edit_spesa':
                    if (canManageBudget()) {
                        $id = $_POST['id'];
                        $descrizione = sanitizeInput($_POST['descrizione']);
                        $importo = floatval($_POST['importo']);
                        $data = $_POST['data'];
                        
                        $stmt = $conn->prepare("UPDATE SPESA SET descrizione = ?, importo = ?, data = ? WHERE ID_Spesa = ?");
                        $stmt->bind_param("sdsi", $descrizione, $importo, $data, $id);
                        $stmt->execute();
                    }
                    break;

            case 'delete_spesa':
                if (canManageBudget()) {
                    $id = $_POST['id'];
                    $stmt = $conn->prepare("DELETE FROM SPESA WHERE ID_Spesa = ?");
                    $stmt->bind_param("i", $id);
                    $stmt->execute();
                }
                break;
        }
        
        // Reindirizza per evitare il refresh della pagina
        header('Location: budget.php');
        exit();
    }
}

// Recupera il budget del matrimonio
$stmt = $conn->prepare("SELECT * FROM BUDGET WHERE ID_Matrimonio = ?");
$stmt->bind_param("i", $wedding_id);
$stmt->execute();
$budget = $stmt->get_result()->fetch_assoc();

$importo_totale = $budget['importo_totale'] ?? 0;

// Recupera le spese
$stmt = $conn->prepare("SELECT s.*, b.ID_Matrimonio 
                       FROM SPESA s 
                       JOIN BUDGET b ON s.ID_Budget = b.ID_Budget 
                       WHERE b.ID_Matrimonio = ? 
                       ORDER BY s.data DESC");
$stmt->bind_param("i", $wedding_id);
$stmt->execute();
$spese = $stmt->get_result();

// Calcola il totale delle spese
$totale_spese = 0;
while ($spesa = $spese->fetch_assoc()) {
    $totale_spese += $spesa['importo'];
}

// Resetta il puntatore del risultato
$spese->data_seek(0);

// Calcola il saldo rimanente
$saldo_rimanente = $importo_totale - $totale_spese;

$page_title = "Gestione Budget";
include 'includes/header.php';
?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Budget</h5>
                    <?php if (canManageBudget()): ?>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#editBudgetModal">
                            <i class="fas fa-edit"></i> Modifica Budget
                        </button>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="alert alert-info">
                                <h5>Budget Totale: €<?php echo number_format($importo_totale, 2); ?></h5>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="alert alert-warning">
                                <h5>Totale Spese: €<?php echo number_format($totale_spese, 2); ?></h5>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="alert <?php echo $saldo_rimanente >= 0 ? 'alert-success' : 'alert-danger'; ?>">
                                <h5>Saldo Rimanente: €<?php echo number_format($saldo_rimanente, 2); ?></h5>
                            </div>
                        </div>
                    </div>

                    <?php if ($saldo_rimanente < 0): ?>
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-triangle"></i> Attenzione: Il budget è stato superato di €<?php echo number_format(abs($saldo_rimanente), 2); ?>!
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Lista Spese</h5>
                    <?php if (canManageBudget()): ?>
                        <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addExpenseModal">
                            <i class="fas fa-plus"></i> Nuova Spesa
                        </button>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Data</th>
                                    <th>Descrizione</th>
                                    <th>Importo</th>
                                    <?php if (canManageBudget()): ?>
                                        <th class="text-center">Azioni</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($spesa = $spese->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo date('d/m/Y', strtotime($spesa['data'])); ?></td>
                                        <td><?php echo htmlspecialchars($spesa['descrizione']); ?></td>
                                        <td>€<?php echo number_format($spesa['importo'], 2); ?></td>
                                        <?php if (canManageBudget()): ?>
                                            <td class="text-center">
                                                <div class="btn-group gap-2">
                                                    <button type="button" class="btn btn-sm btn-primary" 
                                                            data-bs-toggle="modal" 
                                                            data-bs-target="#editExpenseModal"
                                                            data-id="<?php echo $spesa['ID_Spesa']; ?>"
                                                            data-descrizione="<?php echo htmlspecialchars($spesa['descrizione']); ?>"
                                                            data-importo="<?php echo $spesa['importo']; ?>"
                                                            data-data="<?php echo $spesa['data']; ?>">
                                                        <i class="fas fa-edit"></i>
                                                    </button>
                                                    <form method="POST" class="d-inline">
                                                        <input type="hidden" name="action" value="delete_spesa">
                                                        <input type="hidden" name="id" value="<?php echo $spesa['ID_Spesa']; ?>">
                                                        <button type="submit" class="btn btn-sm btn-danger" 
                                                                onclick="return confirm('Sei sicuro di voler eliminare questa spesa?')">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if (canManageBudget()): ?>
    <!-- Modal Modifica Budget -->
    <div class="modal fade" id="editBudgetModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Modifica Budget</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" onsubmit="return validateBudget(this);">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="update">
                        
                        <div class="mb-3">
                            <label for="importo_totale" class="form-label">Budget Totale</label>
                            <input type="number" step="0.01" class="form-control" id="importo_totale" name="importo_totale" 
                                   value="<?php echo $importo_totale; ?>" required min="0">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annulla</button>
                        <button type="submit" class="btn btn-primary">Salva Modifiche</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Aggiungi Spesa -->
    <div class="modal fade" id="addExpenseModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Nuova Spesa</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="" onsubmit="return ValidateDate(this) && validateSpesa(this);">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add_spesa">
                        
                        <div class="mb-3">
                            <label for="descrizione" class="form-label">Descrizione</label>
                            <input type="text" class="form-control" id="descrizione" name="descrizione" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="importo" class="form-label">Importo</label>
                            <input type="number" step="0.01" class="form-control" id="importo" name="importo" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="data" class="form-label">Data</label>
                            <input type="date" class="form-control" id="data" name="data" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annulla</button>
                        <button type="submit" class="btn btn-success">Salva Spesa</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Modifica Spesa -->
    <div class="modal fade" id="editExpenseModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Modifica Spesa</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" onsubmit="return ValidateDate(this) && validateSpesa(this);">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="edit_spesa">
                        <input type="hidden" name="id" id="edit_id">
                        
                        <div class="mb-3">
                            <label for="edit_descrizione" class="form-label">Descrizione</label>
                            <input type="text" class="form-control" id="edit_descrizione" name="descrizione" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="edit_importo" class="form-label">Importo</label>
                            <input type="number" step="0.01" class="form-control" id="edit_importo" name="importo" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="edit_data" class="form-label">Data</label>
                            <input type="date" class="form-control" id="edit_data" name="data" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annulla</button>
                        <button type="submit" class="btn btn-primary">Salva Modifiche</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        //Gestione del modal di modifica
        const editModal = document.getElementById('editExpenseModal');
        if (editModal) {
            editModal.addEventListener('show.bs.modal', function(event) {
                const button = event.relatedTarget;
                
                document.getElementById('edit_id').value = button.getAttribute('data-id');
                document.getElementById('edit_descrizione').value = button.getAttribute('data-descrizione');
                document.getElementById('edit_importo').value = button.getAttribute('data-importo');
                document.getElementById('edit_data').value = button.getAttribute('data-data');
            });
        }
    });
    </script>
<?php endif; ?>

<script>
<?php echo ValidateDate(); ?>
<?php echo ValidateBudget(); ?>
<?php echo ValidateSpesa(); ?>
</script>

<?php include 'includes/footer.php'; ?>