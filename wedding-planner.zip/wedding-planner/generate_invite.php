<?php
require_once 'config/config.php';
require_once 'includes/functions.php';

// Verifica se l'utente è autenticato
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Recupera l'ID del matrimonio dalla sessione
$wedding_id = $_SESSION['wedding_id'] ?? 1;

// Recupera gli inviti attivi
$query = "SELECT * FROM INVITE_TOKEN WHERE wedding_id = $wedding_id ORDER BY expires_at DESC";
$inviti_result = mysqli_query($conn, $query);

// Se è stato inviato il form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $role = intval($_POST['role']); // 2 per Wedding Planner, 3 per Invitato

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Email non valida";
    } else {
        // Genera un token univoco
        $token = bin2hex(random_bytes(32));
        $expires_at = date('Y-m-d H:i:s', strtotime('+7 days'));

        // Inserisce il token nel database
        $stmt = $conn->prepare("INSERT INTO INVITE_TOKEN (token, wedding_id, ID_Ruolo, expires_at) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("siis", $token, $wedding_id, $role, $expires_at);
        
        if ($stmt->execute()) {
            // Genera il link di invito
            $invite_link = "http://" . $_SERVER['HTTP_HOST'] . "/wedding-planner/register_invite.php?token=" . $token;
            
            // Invia l'email con il link
            $subject = "Invito al matrimonio";
            $body = "Ciao,sei stato invitato a partecipare al nostro matrimonio. Usa il link seguente per registrarti:\r\n";
            $body .= "$invite_link";
            
         //se fosse stato attivo un servizio di invio email esterno
           /* if (sendNotification($email, $subject, $body)) {                          
                $_SESSION['invite_success'] = "Invito inviato con successo!"; */

            // Uso noreply@localhost per l'invio email locale
            if (sendNotification("noreply@localhost", $subject, $body)) {
                $_SESSION['invite_success'] = "Invito inviato con successo! Controlla la cartella C:\\xampp\\MercuryMail 
                per vedere l'email. In alternativa <a href='http://localhost/wedding-planner/register_invite.php?token=" . $token . "'>Clicca qui</a>";
            } else {
                $_SESSION['invite_error'] = "Errore nell'invio dell'email, ma l'invito è 
                stato creato. <a href='http://localhost/wedding-planner/register_invite.php?token=" . $token . "'>Il tuo token è: " . $token . "</a>";
            }
        } else {
            $_SESSION['invite_error'] = "Errore nella creazione dell'invito "; //. $stmt->error;
        }
        
        // Redirect per evitare il loop di richieste POST
        header('Location: ' . $_SERVER['PHP_SELF']);
        exit();
    }
}

// Recupera i messaggi dalla sessione
$success = $_SESSION['invite_success'] ?? null;
$error = $_SESSION['invite_error'] ?? null;

// Rimuove i messaggi dalla sessione dopo averli mostrati
unset($_SESSION['invite_success']);
unset($_SESSION['invite_error']);

$page_title = "Gestione Inviti";
include 'includes/header.php'; 
?>

<div class="container">
    <h2>Gestione Inviti</h2>
    
    <?php if ($success): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h5>Genera Nuovo Invito</h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="" id="inviteForm">
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                        <div class="mb-3">
                            <label for="role" class="form-label">Tipo di Invito</label>
                            <select class="form-select" id="role" name="role" required>
                                <option value="3">Invitato</option>
                                <option value="2">Wedding Planner</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary" id="submitBtn">Genera Invito</button>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h5>Inviti Attivi</h5>
                </div>
                <div class="card-body">
                    <?php if ($inviti_result->num_rows > 0): ?>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Tipo</th>
                                        <th>Token</th>
                                        <th>Scadenza</th>
                                        <th>Stato</th>
                                        <th>Azioni</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($invito = $inviti_result->fetch_assoc()): ?>
                                        <tr>
                                            <td><?php echo $invito['ID_Ruolo'] == 2 ? 'Wedding Planner' : 'Invitato'; ?></td>
                                            <td>
                                                <div class="d-flex align-items-center">
                                                    <small class="text-muted me-2">
                                                        <?php echo substr($invito['token'], 0, 16) . '...'; ?>
                                                    </small>
                                                    <button class="btn btn-sm btn-outline-secondary" 
                                                            onclick="copyToClipboard('<?php echo $invito['token']; ?>')"
                                                            title="Copia token">
                                                        <i class="fas fa-copy"></i>
                                                    </button>
                                                </div>
                                            </td>
                                            <td><?php echo date('d/m/Y H:i', strtotime($invito['expires_at'])); ?></td>
                                            <td>
                                                <span class="badge bg-<?php 
                                                    echo $invito['used'] ? 'info' : 
                                                        (strtotime($invito['expires_at']) > time() ? 'success' : 'danger'); 
                                                ?>">
                                                    <?php 
                                                    echo $invito['used'] ? 'Usato' : 
                                                        (strtotime($invito['expires_at']) > time() ? 'Attivo' : 'Scaduto'); 
                                                    ?>
                                                </span>
                                            </td>
                                            <td>
                                                <?php if (!$invito['used'] && strtotime($invito['expires_at']) > time()): ?>
                                                    <a href="delete_invite.php?token=<?php echo $invito['token']; ?>" 
                                                       class="btn btn-sm btn-danger"
                                                       onclick="return confirm('Sei sicuro di voler eliminare questo invito?');">
                                                        Elimina
                                                    </a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <p class="text-muted">Nessun invito attivo</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.getElementById('inviteForm').addEventListener('submit', function(e) {
    const role = document.getElementById('role').value;
    if (role === "2") { // Wedding Planner
        if (!confirm("Sei sicuro di voler generare un invito per Wedding Planner? Questo ruolo ha accesso a tutte le funzionalità di gestione del matrimonio")) {
            e.preventDefault();
        }
    }
});

function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(function() {
        alert('Token copiato negli appunti!');
    }).catch(function(err) {
        console.error('Errore durante la copia: ', err);
    });
}
</script>

<?php include 'includes/footer.php'; ?>