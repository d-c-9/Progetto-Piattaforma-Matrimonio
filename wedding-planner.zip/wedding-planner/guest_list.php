<?php
require_once 'config/config.php';
require_once 'includes/functions.php';
require_once 'includes/check_permissions.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$wedding_id = $_SESSION['wedding_id'] ?? 1;

// Verifica i permessi per la gestione degli invitati
if (!canManageGuests()) {
    header('Location: dashboard.php');
    exit();
}

// Gestione delle azioni
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                if (canManageGuests()) {
                    $nome = sanitizeInput($_POST['nome']);
                    $cognome = sanitizeInput($_POST['cognome']);
                    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
                    $telefono = sanitizeInput($_POST['telefono']);
                    $categoria = sanitizeInput($_POST['categoria']);
                    $conferma = sanitizeInput($_POST['conferma']);
                    
                    $stmt = $conn->prepare("INSERT INTO INVITATO (nome, cognome, email, telefono, ID_Categoria, ID_Matrimonio, conferma) VALUES (?, ?, ?, ?, ?, ?, ?)");
                    $stmt->bind_param("ssssiss", $nome, $cognome, $email, $telefono, $categoria, $wedding_id, $conferma);
                    $stmt->execute();
                }
                break;
                
            case 'edit':
                if (canManageGuests()) {
                    $id = $_POST['id'];
                    $nome = sanitizeInput($_POST['nome']);
                    $cognome = sanitizeInput($_POST['cognome']);
                    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
                    $telefono = sanitizeInput($_POST['telefono']);
                    $categoria = sanitizeInput($_POST['categoria']);
                    $conferma = sanitizeInput($_POST['conferma']);
                    
                    $stmt = $conn->prepare("UPDATE INVITATO SET nome = ?, cognome = ?, email = ?, telefono = ?, ID_Categoria = ?, conferma = ? WHERE ID_Invitato = ? AND ID_Matrimonio = ?");
                    $stmt->bind_param("ssssssii", $nome, $cognome, $email, $telefono, $categoria, $conferma, $id, $wedding_id);
                    $stmt->execute();
                }
                break;
                
            case 'delete':
                if (canManageGuests()) {
                    $id = $_POST['id'];
                    $stmt = $conn->prepare("DELETE FROM INVITATO WHERE ID_Invitato = ? AND ID_Matrimonio = ?");
                    $stmt->bind_param("ii", $id, $wedding_id);
                    $stmt->execute();
                }
                break;
        }
        
        // Reindirizza per evitare il refresh della pagina
        header('Location: guest_list.php');
        exit();
    }
}

// Recupera le statistiche degli invitati
$stats = $conn->query("SELECT 
    COUNT(*) as totale,
    SUM(CASE WHEN conferma = 'confermato' THEN 1 ELSE 0 END) as confermati,
    SUM(CASE WHEN conferma = 'rifiutato' THEN 1 ELSE 0 END) as rifiutati,
    SUM(CASE WHEN conferma = 'in attesa' THEN 1 ELSE 0 END) as in_attesa
FROM INVITATO WHERE ID_Matrimonio = $wedding_id")->fetch_assoc();

// Recupera gli invitati con filtro
$where = "WHERE i.ID_Matrimonio = $wedding_id";
if (isset($_GET['stato']) && $_GET['stato'] != '') {
    $stato = $conn->real_escape_string($_GET['stato']);
    $where .= " AND i.conferma = '$stato'";
}
if (isset($_GET['categoria']) && $_GET['categoria'] != '') {
    $categoria = $conn->real_escape_string($_GET['categoria']);
    $where .= " AND i.ID_Categoria = '$categoria'";
}

$query = "SELECT i.*, c.nome as categoria 
          FROM INVITATO i 
          LEFT JOIN CATEGORIA c ON i.ID_Categoria = c.ID_Categoria 
          $where 
          ORDER BY i.nome ASC";
$guests = $conn->query($query);

$page_title = "Lista Invitati";
include 'includes/header.php';
?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Lista Invitati</h5>
                    <?php if (canManageGuests()): ?>
                        <a href="#" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addGuestModal">
                            <i class="fas fa-plus"></i> Nuovo Invitato
                        </a>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <!-- Report Statistico -->
                    <div class="row">
                        <div class="col-md-3">
                            <div class="alert alert-info">
                                <h5>Totale Invitati: <?php echo $stats['totale']; ?></h5>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="alert alert-success">
                                <h5>Confermati: <?php echo $stats['confermati']; ?></h5>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="alert alert-danger">
                                <h5>Rifiutati: <?php echo $stats['rifiutati']; ?></h5>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="alert alert-warning">
                                <h5>In Attesa: <?php echo $stats['in_attesa']; ?></h5>
                            </div>
                        </div>
                    </div>

                    <!-- Filtri -->
                    <form method="GET" class="mb-4">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="input-group mb-3">
                                    <select name="stato" class="form-select">
                                        <option value="">Tutti gli stati</option>
                                        <option value="confermato" <?php echo isset($_GET['stato']) && $_GET['stato'] == 'confermato' ? 'selected' : ''; ?>>Confermati</option>
                                        <option value="rifiutato" <?php echo isset($_GET['stato']) && $_GET['stato'] == 'rifiutato' ? 'selected' : ''; ?>>Rifiutati</option>
                                        <option value="in attesa" <?php echo isset($_GET['stato']) && $_GET['stato'] == 'in attesa' ? 'selected' : ''; ?>>In Attesa</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="input-group mb-3">
                                    <select name="categoria" class="form-select">
                                        <option value="">Tutte le categorie</option>
                                        <?php
                                        $categorie = $conn->query("SELECT * FROM CATEGORIA ORDER BY nome DESC");
                                        while ($categoria = $categorie->fetch_assoc()):
                                        ?>
                                            <option value="<?php echo $categoria['ID_Categoria']; ?>" 
                                                    <?php echo isset($_GET['categoria']) && $_GET['categoria'] == $categoria['ID_Categoria'] ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($categoria['nome']); ?>
                                            </option>
                                        <?php endwhile; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="input-group">
                                    <button type="submit" class="btn btn-primary">Filtra</button>
                                    <?php if (isset($_GET['stato']) || isset($_GET['categoria'])): ?>
                                        <a href="guest_list.php" class="btn btn-secondary ">Reset</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </form>

                    <!-- Tabella Invitati -->
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Nome</th>
                                    <th>Cognome</th>
                                    <th>Email</th>
                                    <th>Telefono</th>
                                    <th>Categoria</th>
                                    <th>Stato</th>
                                    <?php if (canManageGuests()): ?>
                                        <th>Azioni</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($guest = $guests->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($guest['nome']); ?></td>
                                        <td><?php echo htmlspecialchars($guest['cognome']); ?></td>
                                        <td><?php echo htmlspecialchars($guest['email']); ?></td>
                                        <td><?php echo htmlspecialchars($guest['telefono']); ?></td>
                                        <td><?php echo htmlspecialchars($guest['categoria']); ?></td>
                                        <td>
                                            <?php
                                            $stato_class = '';
                                            switch($guest['conferma']) {
                                                case 'confermato':
                                                    $stato_class = 'text-success';
                                                    break;
                                                case 'rifiutato':
                                                    $stato_class = 'text-danger';
                                                    break;
                                                case 'in attesa':
                                                    $stato_class = 'text-warning';
                                                    break;
                                            }
                                            ?>
                                            <span class="<?php echo $stato_class; ?>">
                                                <?php echo ucfirst($guest['conferma']); ?>
                                            </span>
                                        </td>
                                        <?php if (canManageGuests()): ?>
                                            <td>
                                                <button type="button" class="btn btn-sm btn-primary" 
                                                        data-bs-toggle="modal" 
                                                        data-bs-target="#editGuestModal"
                                                        data-id="<?php echo $guest['ID_Invitato']; ?>"
                                                        data-nome="<?php echo htmlspecialchars($guest['nome']); ?>"
                                                        data-cognome="<?php echo htmlspecialchars($guest['cognome']); ?>"
                                                        data-email="<?php echo htmlspecialchars($guest['email']); ?>"
                                                        data-telefono="<?php echo htmlspecialchars($guest['telefono']); ?>"
                                                        data-categoria="<?php echo $guest['ID_Categoria']; ?>"
                                                        data-conferma="<?php echo $guest['conferma']; ?>">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <form method="POST" class="d-inline">
                                                    <input type="hidden" name="action" value="delete">
                                                    <input type="hidden" name="id" value="<?php echo $guest['ID_Invitato']; ?>">
                                                    <button type="submit" class="btn btn-sm btn-danger" 
                                                            onclick="return confirm('Sei sicuro di voler eliminare questo invitato?')">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if (canManageGuests()): ?>
    <!-- Modal Aggiungi Invitato -->
    <div class="modal fade" id="addGuestModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Nuovo Invitato</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add">
                        
                        <div class="mb-3">
                            <label for="nome" class="form-label">Nome</label>
                            <input type="text" class="form-control" id="nome" name="nome" required>
                        </div>

                        <div class="mb-3">
                            <label for="cognome" class="form-label">Cognome</label>
                            <input type="text" class="form-control" id="cognome" name="cognome">
                        </div>
                        
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email">
                        </div>
                        
                        <div class="mb-3">
                            <label for="telefono" class="form-label">Telefono</label>
                            <input type="tel" class="form-control" id="telefono" name="telefono">
                        </div>

                        <div class="mb-3">
                            <label for="categoria" class="form-label">Categoria</label>
                            <select class="form-select" id="categoria" name="categoria" required>
                                <?php
                                $categorie = $conn->query("SELECT * FROM CATEGORIA ORDER BY nome DESC");
                                while ($categoria = $categorie->fetch_assoc()):
                                ?>
                                    <option value="<?php echo $categoria['ID_Categoria']; ?>">
                                        <?php echo htmlspecialchars($categoria['nome']); ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="conferma" class="form-label">Stato</label>
                            <select class="form-select" id="conferma" name="conferma" required>
                                <option value="confermato">Confermato</option>
                                <option value="rifiutato">Rifiutato</option>
                                <option value="in attesa">In attesa</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annulla</button>
                        <button type="submit" class="btn btn-primary">Salva</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Modifica Invitato -->
    <div class="modal fade" id="editGuestModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Modifica Invitato</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="edit">
                        <input type="hidden" name="id" id="edit_id">
                        
                        <div class="mb-3">
                            <label for="edit_nome" class="form-label">Nome</label>
                            <input type="text" class="form-control" id="edit_nome" name="nome" required>
                        </div>

                        <div class="mb-3">
                            <label for="edit_cognome" class="form-label">Cognome</label>
                            <input type="text" class="form-control" id="edit_cognome" name="cognome">
                        </div>
                        
                        <div class="mb-3">
                            <label for="edit_email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="edit_email" name="email">
                        </div>
                        
                        <div class="mb-3">
                            <label for="edit_telefono" class="form-label">Telefono</label>
                            <input type="tel" class="form-control" id="edit_telefono" name="telefono">
                        </div>

                        <div class="mb-3">
                            <label for="edit_categoria" class="form-label">Categoria</label>
                            <select class="form-select" id="edit_categoria" name="categoria" required>
                                <?php
                                $categorie->data_seek(0);
                                while ($categoria = $categorie->fetch_assoc()):
                                ?>
                                    <option value="<?php echo $categoria['ID_Categoria']; ?>">
                                        <?php echo htmlspecialchars($categoria['nome']); ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="edit_conferma" class="form-label">Stato</label>
                            <select class="form-select" id="edit_conferma" name="conferma" required>
                                <option value="in attesa">In attesa</option>
                                <option value="confermato">Confermato</option>
                                <option value="rifiutato">Rifiutato</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annulla</button>
                        <button type="submit" class="btn btn-primary">Salva Modifiche</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php endif; ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Gestione del modal di modifica
    const editModal = document.getElementById('editGuestModal');
    if (editModal) {
        editModal.addEventListener('show.bs.modal', function(event) {
            const button = event.relatedTarget;
            const id = button.getAttribute('data-id');
            const nome = button.getAttribute('data-nome');
            const cognome = button.getAttribute('data-cognome');
            const email = button.getAttribute('data-email');
            const telefono = button.getAttribute('data-telefono');
            const categoria = button.getAttribute('data-categoria');
            const conferma = button.getAttribute('data-conferma');
            
            document.getElementById('edit_id').value = id;
            document.getElementById('edit_nome').value = nome;
            document.getElementById('edit_cognome').value = cognome;
            document.getElementById('edit_email').value = email;
            document.getElementById('edit_telefono').value = telefono;
            document.getElementById('edit_categoria').value = categoria;
            document.getElementById('edit_conferma').value = conferma;
        });
    }
});
</script>

<?php include 'includes/footer.php'; ?>