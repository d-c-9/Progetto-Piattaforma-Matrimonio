<?php
require_once 'config/config.php';
require_once 'includes/functions.php';
require_once 'includes/check_permissions.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$wedding_id = $_SESSION['wedding_id'] ?? 1;

// Verifica i permessi per la gestione degli eventi
if (!canManageEvents()) {
    header('Location: dashboard.php');
    exit();
}

// Gestione delle azioni
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                if (canManageEvents()) {
                    $stmt = $conn->prepare("INSERT INTO EVENTO (nome, data, ora, descrizione, location, ID_Matrimonio) VALUES (?, ?, ?, ?, ?, ?)");
                    $stmt->bind_param("sssssi", 
                        sanitizeInput($_POST['nome']),
                        $_POST['data'],
                        $_POST['ora'],
                        sanitizeInput($_POST['descrizione']),
                        sanitizeInput($_POST['location']),
                        $wedding_id
                    );
                    $stmt->execute();
                }
                break;
                
            case 'edit':
                if (canManageEvents()) {
                    $id = $_POST['id'];
                    $stmt = $conn->prepare("UPDATE EVENTO SET nome = ?, data = ?, ora = ?, descrizione = ?, location = ? WHERE ID_Evento = ? AND ID_Matrimonio = ?");
                    $stmt->bind_param("sssssii", 
                        sanitizeInput($_POST['nome']),
                        $_POST['data'],
                        $_POST['ora'],
                        sanitizeInput($_POST['descrizione']),
                        sanitizeInput($_POST['location']),
                        $id,
                        $wedding_id
                    );
                    $stmt->execute();
                }
                break;
                
            case 'delete':
                if (canManageEvents()) {
                    $id = $_POST['id'];
                    $stmt = $conn->prepare("DELETE FROM EVENTO WHERE ID_Evento = ? AND ID_Matrimonio = ?");
                    $stmt->bind_param("ii", $id, $wedding_id);
                    $stmt->execute();
                }
                break;
        }
        
        // Reindirizza per evitare il refresh della pagina
        header('Location: events.php');
        exit();
    }
}

// Recupera gli eventi
$stmt = $conn->prepare("SELECT * FROM EVENTO WHERE ID_Matrimonio = ? ORDER BY data ASC");
$stmt->bind_param("i", $wedding_id);
$stmt->execute();
$events = $stmt->get_result();

$page_title = "Gestione Eventi";
include 'includes/header.php';
?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <div class="d-flex align-items-center">
                        <h5 class="mb-0 me-3">Eventi</h5>
                        <span class="badge bg-primary rounded-pill">
                            <?php 
                            $count = $events->num_rows;
                            echo $count . ' ' . ($count == 1 ? 'evento' : 'eventi');
                            ?>
                        </span>
                    </div>
                    <?php if (canManageEvents()): ?>
                        <a href="#" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addEventModal">
                            <i class="fas fa-plus"></i> Nuovo Evento
                        </a>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Nome</th>
                                    <th>Data</th>
                                    <th>Ora</th>
                                    <th>Luogo</th>
                                    <th>Descrizione</th>
                                    <?php if (canManageEvents()): ?>
                                        <th>Azioni</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($event = $events->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($event['nome']); ?></td>
                                        <td><?php echo date('d/m/Y', strtotime($event['data'])); ?></td>
                                        <td><?php echo $event['ora']; ?></td>
                                        <td><?php echo htmlspecialchars($event['location']); ?></td>
                                        <td><?php echo htmlspecialchars($event['descrizione']); ?></td>
                                        <?php if (canManageEvents()): ?>
                                            <td>
                                                <button type="button" class="btn btn-sm btn-primary" 
                                                        data-bs-toggle="modal" 
                                                        data-bs-target="#editEventModal"
                                                        data-id="<?php echo $event['ID_Evento']; ?>"
                                                        data-nome="<?php echo htmlspecialchars($event['nome']); ?>"
                                                        data-data="<?php echo $event['data']; ?>"
                                                        data-ora="<?php echo $event['ora']; ?>"
                                                        data-location="<?php echo htmlspecialchars($event['location']); ?>"
                                                        data-descrizione="<?php echo htmlspecialchars($event['descrizione']); ?>">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <form method="POST" class="d-inline">
                                                    <input type="hidden" name="action" value="delete">
                                                    <input type="hidden" name="id" value="<?php echo $event['ID_Evento']; ?>">
                                                    <button type="submit" class="btn btn-sm btn-danger" 
                                                            onclick="return confirm('Sei sicuro di voler eliminare questo evento?')">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if (canManageEvents()): ?>
    <!-- Modal Aggiungi Evento -->
    <div class="modal fade" id="addEventModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Nuovo Evento</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="" onsubmit="return ValidateDate(this);">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add">
                        <div class="mb-3">
                            <label for="nome" class="form-label">Nome Evento</label>
                            <input type="text" class="form-control" id="nome" name="nome" required>
                        </div>
                        <div class="mb-3">
                            <label for="data" class="form-label">Data</label>
                            <input type="date" class="form-control" id="data" name="data" required>
                        </div>
                        <div class="mb-3">
                            <label for="ora" class="form-label">Ora</label>
                            <input type="time" class="form-control" id="ora" name="ora" required>
                        </div>
                        <div class="mb-3">
                            <label for="location" class="form-label">Luogo</label>
                            <input type="text" class="form-control" id="location" name="location" required>
                        </div>
                        <div class="mb-3">
                            <label for="descrizione" class="form-label">Descrizione</label>
                            <textarea class="form-control" id="descrizione" name="descrizione" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annulla</button>
                        <button type="submit" class="btn btn-primary">Aggiungi Evento</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Modifica Evento -->
    <div class="modal fade" id="editEventModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Modifica Evento</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" onsubmit="return ValidateDate(this);">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="edit">
                        <input type="hidden" name="id" id="edit_id">
                        
                        <div class="mb-3">
                            <label for="edit_nome" class="form-label">Nome Evento</label>
                            <input type="text" class="form-control" id="edit_nome" name="nome" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="edit_data" class="form-label">Data</label>
                            <input type="date" class="form-control" id="edit_data" name="data" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="edit_ora" class="form-label">Ora</label>
                            <input type="time" class="form-control" id="edit_ora" name="ora" required>
                        </div>

                        <div class="mb-3">
                            <label for="edit_location" class="form-label">Luogo</label>
                            <input type="text" class="form-control" id="edit_location" name="location" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="edit_descrizione" class="form-label">Descrizione</label>
                            <textarea class="form-control" id="edit_descrizione" name="descrizione" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annulla</button>
                        <button type="submit" class="btn btn-primary">Salva Modifiche</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php endif; ?>

<script>
<?php echo ValidateDate(); ?>

document.addEventListener('DOMContentLoaded', function() {
    // Gestione del modal di modifica
    const editModal = document.getElementById('editEventModal');
    if (editModal) {
        editModal.addEventListener('show.bs.modal', function(event) {
            const button = event.relatedTarget;
            const id = button.getAttribute('data-id');
            const nome = button.getAttribute('data-nome');
            const data = button.getAttribute('data-data');
            const ora = button.getAttribute('data-ora');
            const location = button.getAttribute('data-location');
            const descrizione = button.getAttribute('data-descrizione');
            
            document.getElementById('edit_id').value = id;
            document.getElementById('edit_nome').value = nome;
            document.getElementById('edit_data').value = data;
            document.getElementById('edit_ora').value = ora;
            document.getElementById('edit_location').value = location;
            document.getElementById('edit_descrizione').value = descrizione;
        });
    }
});
</script>

<?php include 'includes/footer.php'; ?>
