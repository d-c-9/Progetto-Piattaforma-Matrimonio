<?php
require_once 'config/config.php';
require_once 'includes/functions.php';
require_once 'includes/check_permissions.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$wedding_id = $_SESSION['wedding_id'] ?? 1;

// Gestione della modifica
if ($_SERVER['REQUEST_METHOD'] === 'POST' && canManageWedding()) {
    $stmt = $conn->prepare("UPDATE MATRIMONIO SET data = ?, location = ?, descrizione = ? WHERE ID_Matrimonio = ?");
    $stmt->bind_param("sssi", 
        $_POST['data'],
        sanitizeInput($_POST['location']),
        sanitizeInput($_POST['descrizione']),
        $wedding_id
    );
    
    if ($stmt->execute()) {
        $_SESSION['success_message'] = "Dettagli del matrimonio aggiornati con successo!";
    } else {
        $_SESSION['error_message'] = "Errore durante l'aggiornamento dei dettagli";
    }
    
    header('Location: wedding_details.php');
    exit();
}

// Recupera i dettagli del matrimonio
$stmt = $conn->prepare("SELECT * FROM MATRIMONIO WHERE ID_Matrimonio = ?");
$stmt->bind_param("i", $wedding_id);
$stmt->execute();
$wedding = $stmt->get_result()->fetch_assoc();

$page_title = "Dettagli Matrimonio";
include 'includes/header.php';
?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Dettagli Matrimonio</h5>
                    <?php if (canManageWedding()): ?>
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#editWeddingModal">
                            <i class="fas fa-edit"></i> Modifica
                        </button>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <?php if (isset($_SESSION['success_message'])): ?>
                        <div class="alert alert-success">
                            <?php 
                            echo $_SESSION['success_message'];
                            unset($_SESSION['success_message']);
                            ?>
                        </div>
                    <?php endif; ?>

                    <?php if (isset($_SESSION['error_message'])): ?>
                        <div class="alert alert-danger">
                            <?php 
                            echo $_SESSION['error_message'];
                            unset($_SESSION['error_message']);
                            ?>
                        </div>
                    <?php endif; ?>

                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Data:</div>
                        <div class="col-md-8"><?php echo date('d/m/Y', strtotime($wedding['data'])); ?></div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4 fw-bold">Location:</div>
                        <div class="col-md-8"><?php echo htmlspecialchars($wedding['location']); ?></div>
                    </div>
                    <div class="row">
                        <div class="col-md-4 fw-bold">Descrizione:</div>
                        <div class="col-md-8"><?php echo nl2br(htmlspecialchars($wedding['descrizione'])); ?></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if (canManageWedding()): ?>
<!-- Modal Modifica Matrimonio -->
<div class="modal fade" id="editWeddingModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Modifica Dettagli Matrimonio</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" onsubmit="return ValidateDate(this);">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="data" class="form-label">Data</label>
                        <input type="date" class="form-control" id="data" name="data" 
                               value="<?php echo $wedding['data']; ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="location" class="form-label">Location</label>
                        <input type="text" class="form-control" id="location" name="location" 
                               value="<?php echo htmlspecialchars($wedding['location']); ?>" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="descrizione" class="form-label">Descrizione</label>
                        <textarea class="form-control" id="descrizione" name="descrizione" 
                                  rows="4"><?php echo htmlspecialchars($wedding['descrizione']); ?></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Annulla</button>
                    <button type="submit" class="btn btn-primary">Salva Modifiche</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
<?php echo ValidateDate(); ?>
</script>
<?php endif; ?>

<?php include 'includes/footer.php'; ?> 