</div><!-- Chiusura del container dal header.php -->
</main><!-- Chiusura del main dal header.php -->

<!-- Footer -->
<footer class="bg-dark text-white py-4 mt-auto footer">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h5><i class="fas fa-heart text-danger"></i> Matrimonio</h5>
                <p>Il modo più semplice per pianificare il matrimonio perfetto</p>
            </div>
            <div class="col-md-6 text-md-end">
                <div class="mb-2">
                </div>
                <p>&copy; <?php echo date('Y'); ?> Portale Matrimonio</p>
            </div>
        </div>
    </div>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>