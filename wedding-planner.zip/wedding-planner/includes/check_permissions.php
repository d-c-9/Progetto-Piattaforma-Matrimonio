<?php
// Verifica se l'utente ha il ruolo richiesto (verifica di autorizzazione per mostrare o nascondere elementi dell'interfaccia)
function checkUserRole($required_role) {  
    global $conn;
    
    if (!isset($_SESSION['user_id']) || !isset($_SESSION['wedding_id'])) {
        return false;
    }
    
    $stmt = $conn->prepare("SELECT ID_Ruolo FROM PARTECIPAZIONE WHERE ID_Utente = ? AND ID_Matrimonio = ?");
    $stmt->bind_param("ii", $_SESSION['user_id'], $_SESSION['wedding_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    $role = $result->fetch_assoc()['ID_Ruolo'];
    
    return $role == $required_role;
}
 // Verifica se l'utente ha il ruolo richiesto bloccando l'accesso a una pagina o funzionalità se l'utente non ha il ruolo necessario
function requireRole($required_role) {
    if (!checkUserRole($required_role)) {
        header("Location: dashboard.php");
        exit();
    }
}

// Funzioni specifiche per i permessi
function canManageGuests() {
    return checkUserRole(1) || checkUserRole(2); // Solo Coppia o Wedding Planner possono gestire gli invitati
}
function canManageWedding() {
    return checkUserRole(1) || checkUserRole(2); 
}

function canManageEvents() {
    return checkUserRole(1) || checkUserRole(2); 
}

function canManageBudget() {
    return checkUserRole(1) || checkUserRole(2); 
}

function canGenerateInvites() {
    return checkUserRole(1) || checkUserRole(2); 
}

function canViewTimeline() {
    return true; // Tutti possono vedere la timeline
}

function canViewNotifications() {
    return true; 
}

function canRespondToInvitation() {
    return checkUserRole(3); // Solo gli invitati
}

function canViewWeddingDetails() {
       return true;
} 