<?php

function sanitizeInput($input) {
    return htmlspecialchars(strip_tags(trim($input)));
}

function sendNotification($to, $subject, $body) {
    // Headers per l'invio di email HTML
    $headers = array(
        'MIME-Version: 1.0',
        'Content-type: text/html; charset=utf-8',
        'From: Wedding Planner <noreply@localhost>',
        'Reply-To: noreply@localhost',
        'X-Mailer: PHP/' . phpversion()
    );

    // Converte l'array degli headers in stringa
    $headers = implode("\r\n", $headers);

    try {
        // Invia l'email
        $success = mail($to, $subject, $body, $headers);
        
        if ($success) {
            return true;
        } else {
            error_log("Errore nell'invio dell'email a: " . $to);
            return false;
        }
    } catch (Exception $e) {
        error_log("Errore nell'invio dell'email: " . $e->getMessage());
        return false;
    }
}

/* Funzione JavaScript per validare se le date sono antecedenti alla data odierna */
 
function ValidateDate() {
    return "
    function ValidateDate(form) {
        const dateInput = form.querySelector('input[type=\"date\"]');
        const selectedDate = new Date(dateInput.value);
        const today = new Date();
        
        // Resettiamo le ore per confrontare solo le date
        selectedDate.setHours(0, 0, 0, 0);
        today.setHours(0, 0, 0, 0);
        
        if (selectedDate < today) {
            return confirm('Attenzione: la data selezionata è nel passato. Sei sicuro di voler continuare?');
        }
        return true;
    }";
}

/* Funzione JavaScript per validare che il budget non sia negativo */
function ValidateBudget() {
    return "
    function validateBudget(form) {
        const importo = parseFloat(form.importo_totale.value);
        if (importo < 0) {
            alert('Il valore deve essere superiore o uguale a 0');
            return false;
        }
        return true;
    }";
}

/* Funzione JavaScript per validare che l'importo della spesa non sia negativo */
function ValidateSpesa() {
    return "
    function validateSpesa(form) {
        const importo = parseFloat(form.importo.value);
        if (importo < 0) {
            alert('L\\'importo della spesa deve essere superiore o uguale a 0');
            return false;
        }
        return true;
    }";
}

?>