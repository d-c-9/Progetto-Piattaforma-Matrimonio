<!DOCTYPE html>
<html lang="it" class="h-100">
<head>
  <meta charset="UTF-8">
  <title><?php echo isset($page_title) ? $page_title : 'Matrimonio'; ?></title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <style>
    main {
      flex: 1 0 auto;
    }
  </style>
</head>
<body class="d-flex flex-column h-100">
  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="index.php">
            <i class="fas fa-heart text-danger"></i> Matrimonio
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav"> <!-- Posiziona il tasto home a sx -->
                <?php if(isset($_SESSION['user_id'])): ?>
                    <li class="nav-item"><a class="nav-link active" href="index.php">Home</a></li>
                </ul>
                <ul class="navbar-nav ms-auto"> <!-- Posiziona il resto dei tasti a dx -->
                    <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
                <?php else: ?>
                    <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
                    <li class="nav-item"><a class="nav-link" href="registration.php">Registrazione</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
  <!-- Tasto azione indietro -->
  <nav class="navbar navbar-light bg-light shadow-sm p-2">
  <div class="container">
    <div class="d-flex gap-2 ms-auto">
      <?php if (basename($_SERVER['PHP_SELF']) !== 'dashboard.php'): ?>
      <button onclick="history.back()" class="btn btn-secondary"><i class="fas fa-arrow-left"></i></button>
      <?php endif; ?>
    </div>
  </div>
</nav>
  <main class="flex-shrink-0">
    <div class="container mt-4">
</body>