<?php

use PHPUnit\Framework\TestCase;

class LoginTest extends TestCase
{
    private $conn;

    protected function setUp(): void
    {
        // Configurazione della connessione al database di test
        $this->conn = new mysqli("localhost", "root", "", "datab matrimonio");
        
        if ($this->conn->connect_error) {
            die("Connessione fallita: " . $this->conn->connect_error);
        }

    }

    public function testLoginSuccess()
    {
        // Avvia la transazione per mantenere il database pulito
        $this->conn->begin_transaction();
    
        try {
            // creazione utente di test con username unico
            $username = "testuser_login_" . time();
            $email = "test.login@test.com";
            $password = password_hash("password123", PASSWORD_DEFAULT);
    
            $sql = "INSERT INTO utente (username, email, password) VALUES (?, ?, ?)";
            $stmt = $this->conn->prepare($sql);
            $stmt->bind_param("sss", $username, $email, $password);
            $stmt->execute();
    
            // Test di login con credenziali valide
            $sql = "SELECT * FROM utente WHERE username = ?";
            $stmt = $this->conn->prepare($sql);
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $result = $stmt->get_result();
    
            $this->assertGreaterThan(0, $result->num_rows);
    
            $user = $result->fetch_assoc();
            $this->assertTrue(password_verify("password123", $user['password']));
        } finally {
            // Rollback della transazione per eliminare i dati inseriti
            $this->conn->rollback();
        }
    }
    

    public function testLoginFailure()
    {
        // Test di login con credenziali non valide
        $username = "wrongtestusername97654";
        
        $sql = "SELECT * FROM utente WHERE username = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $this->assertEquals(0, $result->num_rows); //ci aspettiamo che non ci siano utenti con questo username
        
        if ($result->num_rows === 0) {
            echo " Test superato come previsto: nessun utente trovato con username '$username'\n";
        }
    }

} 