per la fase di test: installare composer https://getcomposer.org/Composer-Setup.exe
aprire il prompt e una volta che ci siamo spostati nella cartella del progetto 
( cd C:\xampp\htdocs\wedding-planner) 
eseguire il comando per installare phpunit: composer require --dev phpunit/phpunit.

Per lanciare tutti i test: .\   vendor\bin\phpunit --testdox

Altrimenti per un file specifico >vendor\bin\phpunit tests\NomeFileTest.php                                                          (C:\xampp\htdocs\wedding-planner>vendor\bin\phpunit tests\NomeFileTest.php )