<?php

use PHPUnit\Framework\TestCase;
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

class RegistrationTest extends TestCase
{
    private $conn;

    protected function setUp(): void
    {
        $this->conn = new mysqli("localhost", "root", "", "datab matrimonio");
        
        if ($this->conn->connect_error) {
            die("Connessione fallita: " . $this->conn->connect_error);
        }

    }

    public function testSuccessfulRegistration()
    {
        // Avvia la transazione
        $this->conn->begin_transaction();
    
        try {
            $username = "testregistration_" . time();
            $email = "test.registrazione@test.com";
            $password = password_hash("Password123!", PASSWORD_DEFAULT);
    
            $sql = "INSERT INTO utente (username, email, password) VALUES (?, ?, ?)";
            $stmt = $this->conn->prepare($sql);
            $stmt->bind_param("sss", $username, $email, $password);
    
            // Esegue l'inserimento e verifica che l'operazione vada a buon fine
            $this->assertTrue($stmt->execute());
        } finally {
            // Rollback della transazione per rimuovere ogni traccia del test
            $this->conn->rollback();
        }
    }
    

    public function testDuplicateUsername()
    {
        $this->conn->begin_transaction();
    
        try {
            $username = "testduplicateusername";
            $email1 = "user1@test.com";
            $email2 = "user2@test.com";
            $password = password_hash("Password123!", PASSWORD_DEFAULT);
    
            $sql = "INSERT INTO utente (username, email, password) VALUES (?, ?, ?)";
    
            // Primo inserimento che dovrebbe andare a buon fine
            $stmt1 = $this->conn->prepare($sql);
            $stmt1->bind_param("sss", $username, $email1, $password);
            $stmt1->execute();
    
            // Secondo inserimento che utilizza lo stesso username
            $stmt2 = $this->conn->prepare($sql);
            $stmt2->bind_param("sss", $username, $email2, $password);
    
            // Prova a eseguire il secondo inserimento e logga il risultato con var_dump
            $result = $stmt2->execute();
            var_dump($result);  
    
            if ($result === true) {
                // Se l'esecuzione ritorna true, non è stata sollevata eccezione
                $this->fail("La registrazione con username duplicato non ha sollevato errore");
            }
    
            // Rollback della transazione per isolare il test
            $this->conn->rollback();
        } catch (mysqli_sql_exception $e) {
            // Log dell'errore per verificare il messaggio restituito
            var_dump($e->getMessage());
            $this->assertTrue(true);
            $this->conn->rollback();
        }
    }
    
    
} 