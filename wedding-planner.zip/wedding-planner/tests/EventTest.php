<?php

use PHPUnit\Framework\TestCase;

class EventTest extends TestCase
{
    private $conn;
    private $test_matrimonio_id;

    protected function setUp(): void
    {
        $this->conn = new mysqli("localhost", "root", "", "datab matrimonio");
        
        if ($this->conn->connect_error) {
            die("Connessione fallita: " . $this->conn->connect_error);
        }
    }

    public function testCreateEvent()
    {
        // Prima creiamo un matrimonio di test
        $data = "2030-12-31";
        $location = "Test Location";
        $descrizione = "Test Matrimonio";
        
        $sql = "INSERT INTO matrimonio (data, location, descrizione) VALUES (?, ?, ?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("sss", $data, $location, $descrizione);
        $stmt->execute();
        $this->test_matrimonio_id = $this->conn->insert_id;

        // Ora creiamo un evento per questo matrimonio
        $nome_evento = "Cerimonia";
        $data_evento = "2030-12-31";
        $ora_evento = "15:00:00";
        $descrizione_evento = "Cerimonia di matrimonio";
        $location_evento = "Chiesa Test";
        
        $sql = "INSERT INTO evento (nome, data, ora, descrizione, location, ID_Matrimonio) 
                VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("sssssi", $nome_evento, $data_evento, $ora_evento, $descrizione_evento, $location_evento, $this->test_matrimonio_id);
        
        $this->assertTrue($stmt->execute());
        
    }

    public function testUpdateEvent()
    {
        // Prima creiamo un matrimonio e un evento
        $this->testCreateEvent();
        
        // Modifichiamo l'evento
        $nuovo_nome = "Cerimonia Modificata";
        $nuova_data = "2030-12-30";
        $nuova_ora = "16:00:00";
        $nuova_descrizione = "Cerimonia di matrimonio modificata";
        $nuova_location = "Nuova Chiesa";
        
        $sql = "UPDATE evento SET nome = ?, data = ?, ora = ?, descrizione = ?, location = ? 
                WHERE ID_Matrimonio = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("sssssi", $nuovo_nome, $nuova_data, $nuova_ora, $nuova_descrizione, $nuova_location, $this->test_matrimonio_id);
        
        $this->assertTrue($stmt->execute());
    }

    public function testDeleteEvent()
    {
        // Prima creiamo un matrimonio e un evento
        $this->testCreateEvent();
        
        // Eliminiamo l'evento
        $sql = "DELETE FROM evento WHERE ID_Matrimonio = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $this->test_matrimonio_id);
        
        $this->assertTrue($stmt->execute());
        
    }
} 