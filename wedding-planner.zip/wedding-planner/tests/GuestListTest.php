<?php

use PHPUnit\Framework\TestCase;

class GuestListTest extends TestCase
{
    private $conn;
    private $test_matrimonio_id;
    private $test_categoria_id;

    protected function setUp(): void
    {
        $this->conn = new mysqli("localhost", "root", "", "datab matrimonio");
        
        if ($this->conn->connect_error) {
            die("Connessione fallita: " . $this->conn->connect_error);
        }

       /* // Pulisci i dati di test precedenti
        $this->cleanupTestData(); */
    }

    public function testAddGuest()
    {
        // Prima creiamo un matrimonio di test
        $data = "2025-12-31";
        $location = "Test Location";
        $descrizione = "Test Matrimonio";
        
        $sql = "INSERT INTO matrimonio (data, location, descrizione) VALUES (?, ?, ?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("sss", $data, $location, $descrizione);
        $stmt->execute();
        $this->test_matrimonio_id = $this->conn->insert_id;

        // Impostiamo direttamente l'ID della categoria amici (ID = 2)
        $this->test_categoria_id = 2;
        
        // Test per aggiungere un nuovo invitato
        $nome = "Mario";
        $cognome = "Rossi";
        $email = "mario.rossi@test.com";
        $telefono = "3234567890";
        
        $sql = "INSERT INTO invitato (nome, cognome, email, telefono, conferma, ID_Matrimonio, ID_Categoria) 
                VALUES (?, ?, ?, ?, 'in attesa', ?, ?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ssssii", $nome, $cognome, $email, $telefono, $this->test_matrimonio_id, $this->test_categoria_id);
        
        $this->assertTrue($stmt->execute());
        
    }

    public function testUpdateGuest()
    {
        // Prima aggiungiamo un invitato da modificare
        $this->testAddGuest();
        
        // Ora modifichiamo l'invitato
        $email = "mario.rossi@test.com";
        $nuovo_telefono = "3987654320";
        $nuova_conferma = "confermato";
        
        $update_sql = "UPDATE invitato SET telefono = ?, conferma = ? WHERE email = ?";
        $update_stmt = $this->conn->prepare($update_sql);
        $update_stmt->bind_param("sss", $nuovo_telefono, $nuova_conferma, $email);
        
        $this->assertTrue($update_stmt->execute());
        
    }

    public function testDeleteGuest()
    {
        // Prima aggiungiamo un invitato da eliminare
        $this->testAddGuest();
        
        // Test per eliminare un invitato
        $email = "mario.rossi@test.com";
        
        $sql = "DELETE FROM invitato WHERE email = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("s", $email);
        
        $this->assertTrue($stmt->execute());
        
        // Verifica che l'invitato sia stato effettivamente eliminato
        $check_sql = "SELECT * FROM invitato WHERE email = ?";
        $check_stmt = $this->conn->prepare($check_sql);
        $check_stmt->bind_param("s", $email);
        $check_stmt->execute();
        $result = $check_stmt->get_result();
        
        $this->assertEquals(0, $result->num_rows);
    }

}