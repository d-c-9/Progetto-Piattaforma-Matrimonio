<?php

use PHPUnit\Framework\TestCase;

class BudgetTest extends TestCase
{
    private $conn;
    private $test_matrimonio_id;
    private $test_budget_id;
    private $test_spesa_id;

    protected function setUp(): void
    {
        $this->conn = new mysqli("localhost", "root", "", "datab matrimonio");
        
        if ($this->conn->connect_error) {
            die("Connessione fallita: " . $this->conn->connect_error);
        }

    }

    public function testCreateBudget()
    {
        // Prima creiamo un matrimonio di test
        $data = "2030-12-31";
        $location = "Test Location";
        $descrizione = "Test Matrimonio";
        
        $sql = "INSERT INTO matrimonio (data, location, descrizione) VALUES (?, ?, ?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("sss", $data, $location, $descrizione);
        $stmt->execute();
        $this->test_matrimonio_id = $this->conn->insert_id;
        
        // Ora creiamo il budget per questo matrimonio
        $importo_totale = 10000.00;
        $sql = "INSERT INTO budget (importo_totale, ID_Matrimonio) VALUES (?, ?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("di", $importo_totale, $this->test_matrimonio_id);
        
        $this->assertTrue($stmt->execute());
        $this->test_budget_id = $this->conn->insert_id;
        
    }

    public function testAddSpesa()
    {
        // Prima creiamo un matrimonio e un budget
        $this->testCreateBudget();
        
        // Aggiungiamo una spesa
        $importo = 1000.00;
        $descrizione = "Test Spesa";
        $data = date('Y-m-d');
        
        $sql = "INSERT INTO spesa (importo, descrizione, data, ID_Budget) VALUES (?, ?, ?, ?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("dssi", $importo, $descrizione, $data, $this->test_budget_id);
        
        $this->assertTrue($stmt->execute());
        $this->test_spesa_id = $this->conn->insert_id;

    }

    public function testUpdateSpesa()
    {
        // Prima creiamo un matrimonio, un budget e una spesa
        $this->testAddSpesa();
        
        // Modifichiamo la spesa
        $nuovo_importo = 1500.00;
        $nuova_descrizione = "Spesa Modificata";
        $nuova_data = "2030-12-31";
        
        $sql = "UPDATE spesa SET importo = ?, descrizione = ?, data = ? WHERE ID_Spesa = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("dssi", $nuovo_importo, $nuova_descrizione, $nuova_data, $this->test_spesa_id);
        
        $this->assertTrue($stmt->execute());
        
    }

    public function testDeleteSpesa()
    {
        // Prima creiamo un matrimonio, un budget e una spesa
        $this->testAddSpesa();
        
        // Eliminiamo la spesa
        $sql = "DELETE FROM spesa WHERE ID_Spesa = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $this->test_spesa_id);
        
        $this->assertTrue($stmt->execute());
        
    }

}