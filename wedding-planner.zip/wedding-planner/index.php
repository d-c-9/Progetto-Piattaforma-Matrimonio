<?php
session_start();

?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portale Matrimonio</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
      
        .feature-card {
            transition: transform 0.3s;
            margin-bottom: 20px;
        }
        
        .feature-card:hover {
            transform: translateY(-5px);
        }
        
        /* Stile per il messaggio di benvenuto */
        .welcome-alert {
            padding: 0.5rem 1rem;
            margin-bottom: 0.5rem;
            font-size: 0.9rem;
            width: 50%;
            margin-left: auto;
            margin-right: auto;
        }
    </style>
</head>
<body> 
     <!-- Navbar index -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-heart text-danger"></i> Matrimonio
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="#">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="servizi.php">Servizi</a>
                    </li>
                  
                </ul>
                <ul class="navbar-nav ms-auto">
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
                        <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
                    <?php else: ?>
                        <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
                        <li class="nav-item"><a class="nav-link" href="registration.php">Registrati</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>  
    <!-- Hero Section -->
    <div class="position-relative">
    <img src="wedding-foto.jpg" class="w-100" style="height: 600px; object-fit: cover; filter: brightness(50%);">
    <div class="position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center">
        <div class="container text-center text-white">
            <h1 class="display-4 mb-4">Il matrimonio dei tuoi sogni inizia qui</h1>
            <p class="lead mb-5">Pianifica, organizza e gestisci ogni dettaglio del tuo matrimonio</p>
            <?php if (isset($_SESSION['user_id'])): ?>
            <a href="dashboard.php" class="btn btn-primary btn-lg">
                Vai alla dashboard <i class="fas fa-arrow-right ms-2"></i>
            </a>
            <?php else: ?>
            <a href="registration.php" class="btn btn-primary btn-lg">
                Inizia ora <i class="fas fa-arrow-right ms-2"></i>
            </a>
            <?php endif; ?>
        </div>
    </div>
</div>
<!-- Messaggio di benvenuto (solo per utenti loggati) -->
<?php if (isset($_SESSION['user_id'])): ?>
    <div class="container mt-3">
        <div class="alert alert-success welcome-alert text-center">
            Benvenuto, <?php echo htmlspecialchars($_SESSION['username'] ?? 'Utente'); ?>!
        </div>
    </div>
    <?php endif; ?>
    <!-- Features Section -->
    <section class="py-5">
        <div class="container">
            <h2 class="text-center mb-5">Perché scegliere il portale Matrimonio</h2>
            <div class="row">
                <div class="col-md-4">
                    <div class="card feature-card h-100 text-center shadow-sm">
                        <div class="card-body">
                            <i class="fas fa-tasks fs-1 text-primary mb-3"></i>
                            <h4>Organizzazione Completa</h4>
                            <p>Gestisci invitati, budget, eventi in un unico posto</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card feature-card h-100 text-center shadow-sm">
                        <div class="card-body">
                            <i class="fas fa-calendar-check fs-1 text-primary mb-3"></i>
                            <h4>Lista delle Attività</h4>
                            <p>Tieni traccia di tutto ciò che deve essere fatto con promemoria personalizzati</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card feature-card h-100 text-center shadow-sm">
                        <div class="card-body">
                            <i class="fas fa-mobile-alt fs-1 text-primary mb-3"></i>
                            <h4>Accessibile gratuitamente</h4>
                            <p>Accedi al tuo piano di matrimonio in qualsiasi momento senza costi</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Call to Action (contenuto differenziato per utenti loggati/non loggati) -->
    <section class="py-5 bg-light">
        <div class="container text-center">
            <?php if (!isset($_SESSION['user_id'])): ?>
            <h2 class="mb-4">Pronto a iniziare?</h2>
            <a href="registration.php" class="btn btn-primary btn-lg">
                Crea il tuo account gratuito
            </a>
            <?php endif; ?>
        </div>
    </section>
    <?php include 'includes/footer.php'; ?>

    <!-- Bootstrap Bundle con Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>