<?php
require_once 'config/config.php';
// Verifica se l'utente è già autenticato
if(isset($_SESSION['user_id'])) {
    // Reindirizza alla dashboard se l'utente è già loggato
    header("Location: dashboard.php");
    exit;
}

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password'];

    // prepared statement per prevenire SQL injection
    $stmt = $conn->prepare("SELECT * FROM UTENTE WHERE username=?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if($result && mysqli_num_rows($result) == 1){
        $user = mysqli_fetch_assoc($result);
        if(password_verify($password, $user['password'])){
            $_SESSION['user_id'] = $user['ID_Utente'];
            $_SESSION['username'] = $user['username'];
            
            // Ottiene il ruolo dell'utente dalla tabella PARTECIPAZIONE
            $stmt_role = $conn->prepare("SELECT r.ID_Ruolo, r.nome 
                                        FROM PARTECIPAZIONE p 
                                        JOIN RUOLO r ON p.ID_Ruolo = r.ID_Ruolo 
                                        WHERE p.ID_Utente = ? 
                                        LIMIT 1");
            $stmt_role->bind_param("i", $user['ID_Utente']);
            $stmt_role->execute();
            $role_result = $stmt_role->get_result();
            
            if($role_result && mysqli_num_rows($role_result) > 0) {
                $role = mysqli_fetch_assoc($role_result);
                $_SESSION['role'] = $role['ID_Ruolo'];
                $_SESSION['role_name'] = $role['nome'];
            } else {
                $_SESSION['role'] = null;
                $_SESSION['role_name'] = null;
            }
            
            // Ottiene l'ultimo matrimonio dell'utente dalla tabella PARTECIPAZIONE
            $stmt_wedding = $conn->prepare("SELECT m.ID_Matrimonio, m.data, m.location 
                                           FROM PARTECIPAZIONE p 
                                           JOIN MATRIMONIO m ON p.ID_Matrimonio = m.ID_Matrimonio 
                                           WHERE p.ID_Utente = ? 
                                           ORDER BY m.data DESC 
                                           LIMIT 1");
            $stmt_wedding->bind_param("i", $user['ID_Utente']);
            $stmt_wedding->execute();
            $wedding_result = $stmt_wedding->get_result();
            
            if($wedding_result && mysqli_num_rows($wedding_result) > 0) {
                $wedding = mysqli_fetch_assoc($wedding_result);
                $_SESSION['wedding_id'] = $wedding['ID_Matrimonio'];
            } else {
                // Se non ha matrimoni, impostiamo a NULL
                $_SESSION['wedding_id'] = null;
            }
            
            header("Location: dashboard.php");
            exit;
        } else {
            $error = "Password errata";
        }
    } else {
        $error = "Utente non trovato";
    }
}
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        html, body {
            height: 100%;
        }
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            background-color: #f8f9fa;
        }
        .main-content {
            flex: 1 0 auto;
        }
        footer {
            flex-shrink: 0;
        }
        .login-form {
            max-width: 500px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }
        .header-wedding {
            background-color: #f8f9fa;
            padding: 20px 0;
            margin-bottom: 30px;
            text-align: center;
            border-bottom: 1px solid #e9ecef;
        }
        .form-section {
            margin-bottom: 30px;
            padding: 20px;
            background-color: #f8f9fa;
            border-radius: 5px;
        }
        .form-section h3 {
            margin-bottom: 20px;
            color: #6c757d;
        }
        .btn-wedding {
            background-color: #e83e8c;
            color: white;
            border: none;
        }
        .btn-wedding:hover {
            background-color: #d6336c;
            color: white;
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <div class="main-content">
        <div class="container my-5">
            <div class="login-form">
                
                <?php if(isset($error)): ?>
                    <div class="alert alert-danger">
                        <?php echo $error; ?>
                    </div>
                <?php endif; ?>
                
                <form method="POST" action="login.php">
                    <div class="form-section">
                        <h3><i class="fas fa-user"></i> Accedi al tuo Account</h3>
                        
                        <div class="mb-3">
                            <label for="username" class="form-label">Username*</label>
                            <input type="text" class="form-control" id="username" name="username" required>
                        </div>
                        
                        <div class="mb-3">
                            <label for="password" class="form-label">Password*</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                        
                    </div>

                    <div class="text-center">
                        <button type="submit" class="btn btn-wedding btn-lg">
                            <i class="fas fa-sign-in-alt"></i> Accedi
                        </button>
                    </div>
                    
                    <section class="py-3 text-center">
                        <a href="registration.php" class="text-decoration-none">Non hai un account?</a>
                    </section>
                </form>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>