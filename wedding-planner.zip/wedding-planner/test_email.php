<?php
require_once 'config/config.php';
require_once 'includes/functions.php';

// Abilita la visualizzazione degli errori per il debug
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Configurazione email di test
$to = "noreply@localhost"; // Email locale per test
$subject = "Test Invio Email - " . date('Y-m-d H:i:s');
$body = "
<html>
<head>
    <title>Test Email</title>
</head>
<body>
    <h2>Test Invio Email</h2>
    <p>Questa è una email di test per provare la corretta funzionalità. Email inviata il " . date('Y-m-d H:i:s') . "</p>
    <p>Server: " . $_SERVER['SERVER_NAME'] . "</p>
    <p>IP: " . $_SERVER['SERVER_ADDR'] . "</p>
</body>
</html>
";

// Mostra le impostazioni PHP per il debug
echo "<h3>Impostazioni PHP:</h3>";
echo "<pre>";
echo "SMTP: " . ini_get('SMTP') . "\n";
echo "smtp_port: " . ini_get('smtp_port') . "\n";
echo "sendmail_path: " . ini_get('sendmail_path') . "\n";
echo "sendmail_from: " . ini_get('sendmail_from') . "\n";
echo "</pre>";

// Verifica se Mercury è in esecuzione
$mercury_running = false;
$fp = @fsockopen('localhost', 25, $errno, $errstr, 5);
if ($fp) {
    $mercury_running = true;
    fclose($fp);
}

echo "<h3>Stato Mercury:</h3>";
if ($mercury_running) {
    echo "<div style='color: green;'>Mercury è in esecuzione sulla porta 25</div>";
} else {
    echo "<div style='color: red;'>Mercury non è in esecuzione sulla porta 25</div>";
}

// Prova a inviare l'email
echo "<h3>Tentativo di invio email:</h3>";
echo "<p>Inviando a: " . htmlspecialchars($to) . "</p>";
echo "<p>Da: noreply@localhost</p>";

$success = sendNotification($to, $subject, $body);

if ($success) {
    echo "<div style='color: green;'>Email inviata con successo!</div>";
    echo "<p>Controlla la cartella C:\\xampp\\MercuryMail per vedere l'email inviata.</p>";
    
    
} else {
    echo "<div style='color: red;'>Errore nell'invio dell'email.</div>";
}
?>