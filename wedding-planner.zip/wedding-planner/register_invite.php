<?php
require_once 'config/config.php';
require_once 'includes/functions.php';

// Verifica se è stato fornito un token
if (!isset($_GET['token'])) {
    die('Token non fornito');
}

$token = $_GET['token'];

// Verifica se il token è valido e non è scaduto
$stmt = $conn->prepare("SELECT * FROM INVITE_TOKEN WHERE token = ? AND used = 0 AND expires_at > NOW()");
$stmt->bind_param("s", $token);
$stmt->execute();
$result = $stmt->get_result();
$invite = $result->fetch_assoc();


if (!$invite) {
    die('Token non valido o scaduto');
}

// Se il form è stato inviato recupera il token e verifica di nuovo i dati
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $token = $_POST['token'];
    
    // Ricontrollo del token
    $stmt = $conn->prepare("SELECT * FROM INVITE_TOKEN WHERE token = ? AND used = 0 AND expires_at > NOW()");
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();
    $invite = $result->fetch_assoc();
    
    if (!$invite) {
        die('Token non valido o scaduto');
    }
    
    $username =  sanitizeInput($_POST['username']);
    $password = $_POST['password'];
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    
    try {
        // Inizia la transazione
        $conn->begin_transaction();
        
        // Crea l'utente
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO UTENTE (username, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $username, $email, $hashed_password);
        $stmt->execute();
        $new_user_id = $conn->insert_id;
        
        // Crea la partecipazione
        $stmt = $conn->prepare("INSERT INTO PARTECIPAZIONE (ID_Matrimonio, ID_Utente, ID_Ruolo) VALUES (?, ?, ?)");
        $stmt->bind_param("iii", $invite['wedding_id'], $new_user_id, $invite['ID_Ruolo']);
        $stmt->execute();
        
        // Marca il token come usato
        $stmt = $conn->prepare("UPDATE INVITE_TOKEN SET used = 1 WHERE token = ?");
        $stmt->bind_param("s", $token);
        $stmt->execute();
        
        // Crea una notifica di benvenuto
        $messaggio = "Benvenuto! La tua registrazione è stata completata con successo";
        $stmt = $conn->prepare("INSERT INTO NOTIFICA (messaggio, ID_Utente) VALUES (?, ?)");
        $stmt->bind_param("si", $messaggio, $new_user_id);
        $stmt->execute();
        
        // Commit della transazione
        $conn->commit();
        
        $_SESSION['success_message'] = 'Registrazione completata con successo! Ora puoi accedere al tuo account';
        header('Location: login.php');
        exit();
        
    } catch (Exception $e) {
        // Rollback in caso di errore
        $conn->rollback();
        $error = 'Errore durante la registrazione ' ; //. $e->getMessage();
    }
}
$page_title = "Registrazione con Invito";
include 'includes/header.php';
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrazione con Invito</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .registration-form {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }
        .header-wedding {
            background-color: #f8f9fa;
            padding: 20px 0;
            margin-bottom: 30px;
            text-align: center;
            border-bottom: 1px solid #e9ecef;
        }
        .form-section {
            margin-bottom: 30px;
            padding: 20px;
            background-color: #f8f9fa;
            border-radius: 5px;
        }
        .form-section h3 {
            margin-bottom: 20px;
            color: #6c757d;
        }
        .btn-wedding {
            background-color: #e83e8c;
            color: white;
            border: none;
        }
        .btn-wedding:hover {
            background-color: #d6336c;
            color: white;
        }
    </style>
</head>
<body class="bg-light">
   
    
    <div class="container my-5">
        <div class="registration-form">
            <h2 class="text-center mb-4">Registrazione con Invito</h2>
            
            <?php if (isset($error)): ?>
                <div class="alert alert-danger">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="">
                <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
                <input type="hidden" name="wedding_id" value="<?php echo htmlspecialchars($invite['wedding_id']); ?>">
                <input type="hidden" name="role" value="<?php echo htmlspecialchars($invite['ID_Ruolo']); ?>">
                
                <div class="form-section">
                    <h3><i class="fas fa-user"></i> Informazioni Account</h3>
                    
                    <div class="mb-3">
                        <label for="username" class="form-label">Username*</label>
                        <input type="text" class="form-control" id="username" name="username" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="email" class="form-label">Email*</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    
                    <div class="mb-3">
                        <label for="password" class="form-label">Password*</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                </div>

                <div class="text-center">
                    <button type="submit" class="btn btn-wedding btn-lg">
                        <i class="fas fa-user-plus"></i> Registrati
                    </button>
                </div>
                
                <section class="py-4 bg-light">
                    <div class="container text-center">
                        <a href="login.php" class="text-decoration-none">Hai già un account? Accedi</a>
                    </div>
                </section>
            </form>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
