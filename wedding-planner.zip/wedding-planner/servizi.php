<?php
session_start();
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>I Nostri Servizi - Matrimonio</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .service-card {
            transition: transform 0.3s, box-shadow 0.3s;
            height: 100%;
            border: none;
            border-radius: 15px;
        }
        
        .service-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }

        .service-icon {
            font-size: 2.5rem;
            margin-bottom: 1rem;
            color: #0d6efd;
        }
    </style>
</head>
<body>
    <!-- Navbar servizi -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-heart text-danger"></i> Matrimonio
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="#">Servizi</a>
                    </li>
                
                </ul>
                <ul class="navbar-nav ms-auto">
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <li class="nav-item"><a class="nav-link" href="dashboard.php">Dashboard</a></li>
                        <li class="nav-item"><a class="nav-link" href="logout.php">Logout</a></li>
                    <?php else: ?>
                        <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
                        <li class="nav-item"><a class="nav-link" href="registration.php">Registrati</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Header con lo stesso stile di index -->
    <div class="position-relative">
        <img src="wedding-foto.jpg" class="w-100" style="height: 600px; object-fit: cover; filter: brightness(50%);">
        <div class="position-absolute top-0 start-0 w-100 h-100 d-flex align-items-center">
            <div class="container text-center text-white">
                <h1 class="display-4 mb-4">I Nostri Servizi</h1>
                <p class="lead">Tutto ciò di cui hai bisogno per organizzare il tuo matrimonio </p>
            </div>
        </div>
    </div>

    <!-- Servizi -->
    <section class="py-5">
        <div class="container">
            <div class="row g-4">
                <!-- Dettagli Matrimonio -->
                <div class="col-md-6 col-lg-4">
                    <div class="card service-card">
                        <div class="card-body text-center p-4">
                            <i class="fas fa-ring service-icon"></i>
                            <h3 class="card-title h4 mb-3">Dettagli Matrimonio</h3>
                            <p class="card-text">Inserisci e visualizza tutte le informazioni principali del matrimonio, come data, luogo e descrizione. Mantieni tutto organizzato in un unico posto</p>
                        </div>
                    </div>
                </div>

                <!-- Gestione Eventi -->
                <div class="col-md-6 col-lg-4">
                    <div class="card service-card">
                        <div class="card-body text-center p-4">
                            <i class="fas fa-calendar-alt service-icon"></i>
                            <h3 class="card-title h4 mb-3">Gestione Eventi</h3>
                            <p class="card-text">Pianifica e organizza tutti gli eventi collegati al matrimonio, dalla cerimonia al ricevimento, gestendo date, orari e location</p>
                        </div>
                    </div>
                </div>

                <!-- Gestione Invitati -->
                <div class="col-md-6 col-lg-4">
                    <div class="card service-card">
                        <div class="card-body text-center p-4">
                            <i class="fas fa-users service-icon"></i>
                            <h3 class="card-title h4 mb-3">Gestione Invitati</h3>
                            <p class="card-text">Crea e gestisci la lista degli invitati, con funzioni di RSVP e suddivisione in categorie come famiglia, amici e colleghi</p>
                        </div>
                    </div>
                </div>

                <!-- Gestione Budget -->
                <div class="col-md-6 col-lg-4">
                    <div class="card service-card">
                        <div class="card-body text-center p-4">
                            <i class="fas fa-wallet service-icon"></i>
                            <h3 class="card-title h4 mb-3">Gestione Budget</h3>
                            <p class="card-text">Pianifica e monitora il budget del matrimonio, registra le spese effettive e tieni sotto controllo il saldo rimanente</p>
                        </div>
                    </div>
                </div>

                <!-- Generazione Inviti -->
                <div class="col-md-6 col-lg-4">
                    <div class="card service-card">
                        <div class="card-body text-center p-4">
                            <i class="fas fa-envelope service-icon"></i>
                            <h3 class="card-title h4 mb-3">Generazione Inviti</h3>
                            <p class="card-text">Crea inviti personalizzati per permettere agli ospiti di registrarsi facilmente al matrimonio attraverso il portale</p>
                        </div>
                    </div>
                </div>

                <!-- Notifiche -->
                <div class="col-md-6 col-lg-4">
                    <div class="card service-card">
                        <div class="card-body text-center p-4">
                            <i class="fas fa-bell service-icon"></i>
                            <h3 class="card-title h4 mb-3">Notifiche</h3>
                            <p class="card-text">Ricevi e visualizza notifiche in tempo reale per conferme, modifiche e aggiornamenti relativi agli inviti</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include 'includes/footer.php'; ?>

    <!-- Bootstrap Bundle con Popper -->
  <!--  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script> -->
</body>
</html> 