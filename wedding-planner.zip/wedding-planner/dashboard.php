<?php
require_once 'config/config.php';
require_once 'includes/functions.php';
require_once 'includes/check_permissions.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$wedding_id = $_SESSION['wedding_id'] ?? 1;

// Recupera il ruolo dell'utente
$stmt = $conn->prepare("SELECT r.nome as ruolo 
                       FROM PARTECIPAZIONE p 
                       JOIN RUOLO r ON p.ID_Ruolo = r.ID_Ruolo 
                       WHERE p.ID_Utente = ? AND p.ID_Matrimonio = ?");
$stmt->bind_param("ii", $user_id, $wedding_id);
$stmt->execute();
$result = $stmt->get_result();
$role_data = $result->fetch_assoc();
$user_role = $role_data ? $role_data['ruolo'] : 'Non assegnato';

// Recupera le notifiche recenti
$stmt = $conn->prepare("SELECT * FROM NOTIFICA WHERE ID_Utente = ? ORDER BY data_ora DESC LIMIT 40");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$notifications = $stmt->get_result();

// Recupera gli eventi programmati
$stmt = $conn->prepare("SELECT * FROM EVENTO WHERE ID_Matrimonio = ? AND data >= CURDATE() ORDER BY data ASC LIMIT 5");
$stmt->bind_param("i", $wedding_id);
$stmt->execute();
$upcoming_events = $stmt->get_result();

// Gestione del click sul pallino della notifica
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['notification_id'])) {
    $notification_id = $_POST['notification_id'];
    $stmt = $conn->prepare("UPDATE NOTIFICA SET stato = 'letto' WHERE ID_Notifica = ? AND ID_Utente = ? AND stato = 'non_letto'");
    $stmt->bind_param("ii", $notification_id, $user_id);
    $stmt->execute();
    header('Location: dashboard.php');
    exit();
}

$page_title = "Dashboard";
include 'includes/header.php';
?>

<div class="container">
    <div class="row">
        <div class="col-md-8">
            <div class="card mb-4">
                <div class="card-header">
                    <h5>Benvenuto, <?php echo htmlspecialchars($_SESSION['username']); ?></h5>
                    <small class="text-muted">Ruolo: <?php echo htmlspecialchars($user_role); ?></small>
                </div>
                <div class="card-body">
                    <?php if (canViewTimeline()): ?>
                        <h6>Eventi Programmati</h6>
                        <?php if ($upcoming_events->num_rows > 0): ?>
                            <div class="list-group">
                                <?php while ($event = $upcoming_events->fetch_assoc()): ?>
                                    <div class="list-group-item">
                                        <h6 class="mb-1"><?php echo htmlspecialchars($event['nome']); ?></h6>
                                        <small class="text-muted">
                                            Data: <?php echo date('d/m/Y', strtotime($event['data'])); ?> - 
                                            Ora: <?php echo $event['ora']; ?>
                                        </small>
                                    </div>
                                <?php endwhile; ?>
                            </div>
                        <?php else: ?>
                            <p class="text-muted">Nessun evento programmato</p>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>

            <?php if (canViewNotifications()): ?>
                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">Notifiche Recenti</h5>
                        <?php
                        $stmt = $conn->prepare("SELECT COUNT(*) as unread FROM NOTIFICA WHERE ID_Utente = ? AND stato = 'non_letto'");
                        $stmt->bind_param("i", $user_id);
                        $stmt->execute();
                        $unread = $stmt->get_result()->fetch_assoc();
                        if ($unread['unread'] > 0): ?>
                            <span class="text-danger">
                                <i class="fas fa-circle"></i> <?php echo $unread['unread']; ?>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <?php if ($notifications->num_rows > 0): ?>
                            <div class="list-group notification-list" style="max-height: 400px; overflow-y: auto;">
                                <?php while ($notification = $notifications->fetch_assoc()): ?>
                                    <div class="list-group-item border-0">
                                        <div class="d-flex align-items-center">
                                            <form method="POST" class="me-3">
                                                <input type="hidden" name="notification_id" value="<?php echo $notification['ID_Notifica']; ?>">
                                                <button type="submit" class="btn p-0">
                                                    <i class="fas fa-circle" style="font-size: 0.8rem; color: <?php echo $notification['stato'] === 'non_letto' ? '#dc3545' : '#198754'; ?>"></i>
                                                </button>
                                            </form>
                                            <div>
                                                <div class="mb-1"><?php echo htmlspecialchars($notification['messaggio']); ?></div>
                                                <small class="text-muted"><?php echo date('d/m/Y H:i', strtotime($notification['data_ora'])); ?></small>
                                            </div>
                                        </div>
                                    </div>
                                <?php endwhile; ?>
                            </div>
                            
                        <?php else: ?>
                            <p class="text-muted">Nessuna notifica recente</p>
                        <?php endif; ?>
                    </div>
                </div>

                <style>
                .notification-list {
                    max-height: 400px;
                    overflow-y: auto;
                    scrollbar-width: thin;
                }
                .notification-list::-webkit-scrollbar {
                    width: 6px;
                }
                .notification-list::-webkit-scrollbar-track {
                    background: #f1f1f1;
                }
                .notification-list::-webkit-scrollbar-thumb {
                    background: #888;
                    border-radius: 3px;
                }
                .notification-list .list-group-item {
                    transition: all 0.3s ease;
                }
                .notification-list .list-group-item:hover {
                    background-color: #f8f9fa;
                }
                </style>

               
            <?php endif; ?>
        </div>

        <div class="col-md-4">
            <div class="card mb-4">
                <div class="card-header">
                <h5>Azioni Rapide</h5>
                </div>
                <div class="card-body">
                    <div class="list-group">
                        <?php if (canViewWeddingDetails()): ?>
                            <a href="wedding_details.php" class="list-group-item list-group-item-action">
                                <i class="fas fa-ring"></i> Dettagli Matrimonio
                            </a>
                        <?php endif; ?>

                        <?php if (canManageEvents()): ?>
                            <a href="events.php" class="list-group-item list-group-item-action">
                                <i class="fas fa-calendar-alt"></i> Gestisci Eventi
                            </a>
                        <?php endif; ?>

                        <?php if (canManageGuests()): ?>
                            <a href="guest_list.php" class="list-group-item list-group-item-action">
                                <i class="fas fa-users"></i> Gestisci Invitati
                            </a>
                        <?php endif; ?>

                        <?php if (canManageBudget()): ?>
                            <a href="budget.php" class="list-group-item list-group-item-action">
                                <i class="fas fa-wallet"></i> Gestisci Budget
                            </a>
                        <?php endif; ?>

                        <?php if (canGenerateInvites()): ?>
                            <a href="generate_invite.php" class="list-group-item list-group-item-action">
                                <i class="fas fa-user-plus"></i> Genera Inviti
                            </a>
                        <?php endif; ?>

                        <?php if (canRespondToInvitation()): ?>
                            <a href="respond_invitation.php" class="list-group-item list-group-item-action">
                                <i class="fas fa-reply"></i> Rispondi all'Invito
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>