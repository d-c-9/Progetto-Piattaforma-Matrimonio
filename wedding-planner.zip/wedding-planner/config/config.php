<?php
session_start();

// Configurazione database
$host = "localhost";
$user = "root";
$pass = "";
$db   = "datab matrimonio"; 

$conn = mysqli_connect($host, $user, $pass, $db);
if (!$conn) {
    die("Connessione fallita: " . mysqli_connect_error());
}
?>