<?php
require_once 'config/config.php';

if (!isset($_SESSION['user_id']) || !isset($_GET['token'])) {
    header('Location: generate_invite.php');
    exit();
}

$token = $_GET['token'];
$wedding_id = $_SESSION['wedding_id'] ?? 1;

// Verifica che l'invito appartenga al matrimonio dell'utente
$stmt = $conn->prepare("DELETE FROM INVITE_TOKEN WHERE token = ? AND wedding_id = ?");
$stmt->bind_param("si", $token, $wedding_id);

if ($stmt->execute()) {
    $_SESSION['invite_success'] = "Invito eliminato con successo!";
} else {
    $_SESSION['invite_error'] = "Errore nell'eliminazione dell'invito";
}

header('Location: generate_invite.php');
exit(); 