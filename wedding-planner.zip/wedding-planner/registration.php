<?php

require_once 'config/config.php';
require_once 'includes/functions.php';

// Funzione per registrare la coppia e creare il matrimonio
function registraCoppia($username, $password, $email, $data_matrimonio, $location, $descrizione) {
    global $conn;
    
    // Inizio transazione
    $conn->begin_transaction();
    
    try {
        // Hash della password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        // Inserimento utente
        $stmt = $conn->prepare("INSERT INTO UTENTE (username, password, email) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $username, $hashed_password, $email);
        $stmt->execute();
        $id_utente = $stmt->insert_id;
        $stmt->close();
        
        // Inserimento matrimonio
        $stmt = $conn->prepare("INSERT INTO MATRIMONIO (data, location, descrizione) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $data_matrimonio, $location, $descrizione);
        $stmt->execute();
        $id_matrimonio = $stmt->insert_id;
        $stmt->close();
        
      // Uso direttamente l'ID del ruolo "Coppia" 
        $id_ruolo_coppia = 1; 
        
        // Collega l'utente al matrimonio
        $stmt = $conn->prepare("INSERT INTO PARTECIPAZIONE (ID_Matrimonio, ID_Utente, ID_Ruolo) VALUES (?, ?, ?)");
        $stmt->bind_param("iii", $id_matrimonio, $id_utente, $id_ruolo_coppia);
        $stmt->execute();
        $stmt->close();
        
        // Crea il budget iniziale
        $stmt = $conn->prepare("INSERT INTO BUDGET (importo_totale, ID_Matrimonio) VALUES (0.00, ?)");
        $stmt->bind_param("i", $id_matrimonio);
        $stmt->execute();
        $stmt->close();
        
        // Crea una notifica di benvenuto
        $messaggio = "Benvenuti! Il vostro account matrimonio è stato registrato con successo";
        $stmt = $conn->prepare("INSERT INTO NOTIFICA (messaggio, ID_Utente) VALUES (?, ?)");
        $stmt->bind_param("si", $messaggio, $id_utente);
        $stmt->execute();
        $stmt->close();
        
        // Commit della transazione
        $conn->commit();
        
        return [
            'success' => true,
            'id_utente' => $id_utente,
            'id_matrimonio' => $id_matrimonio,
            'message' => 'Registrazione completata con successo! Ora puoi accedere al tuo account'
        ];
    } catch (Exception $e) {
        // Rollback in caso di errore
        $conn->rollback();
        return [
            'success' => false,
            'message' => 'Errore durante la registrazione ' //. $e->getMessage()
        ];
    }
}

// Gestione del form di registrazione
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitizeInput($_POST['username']);
    $password = $_POST['password']; 
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $data_matrimonio = $_POST['data_matrimonio'];
    $location = sanitizeInput($_POST['location']);
    $descrizione = sanitizeInput($_POST['descrizione']);
    
    $result = registraCoppia($username, $password, $email, $data_matrimonio, $location, $descrizione);
    
    if ($result['success']) {
        $_SESSION['success_message'] = $result['message'];
        header('Location: login.php');
        exit();
    } else {
        $error = $result['message'];
    }
}
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrazione Coppia</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .registration-form {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }
        .header-wedding {
            background-color: #f8f9fa;
            padding: 20px 0;
            margin-bottom: 30px;
            text-align: center;
            border-bottom: 1px solid #e9ecef;
        }
        .form-section {
            margin-bottom: 30px;
            padding: 20px;
            background-color: #f8f9fa;
            border-radius: 5px;
        }
        .form-section h3 {
            margin-bottom: 20px;
            color: #6c757d;
        }
        .btn-wedding {
            background-color: #e83e8c;
            color: white;
            border: none;
        }
        .btn-wedding:hover {
            background-color: #d6336c;
            color: white;
        }
    </style>
</head>
<body class="bg-light">
    <?php include 'includes/header.php'; ?>
    <div class="container my-5">
        <div class="registration-form">
            <h2 class="text-center mb-4">Registrazione Coppia</h2>
            
            <?php if (!empty($error)): ?>
                <div class="alert alert-danger">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <div class="form-section">
                    <h3><i class="fas fa-user"></i> Informazioni Account</h3>
                    <div class="mb-3">
                        <label for="username" class="form-label">Username*</label>
                        <input type="text" class="form-control" id="username" name="username" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Password*</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email*</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                </div>
                
                <div class="form-section">
                    <h3><i class="fas fa-calendar-alt"></i> Dettagli Matrimonio</h3>
                    <div class="mb-3">
                        <label for="data_matrimonio" class="form-label">Data Matrimonio*</label>
                        <input type="date" class="form-control" id="data_matrimonio" name="data_matrimonio" required>
                    </div>
                    <div class="mb-3">
                        <label for="location" class="form-label">Location*</label>
                        <input type="text" class="form-control" id="location" name="location" required>
                    </div>
                    <div class="mb-3">
                        <label for="descrizione" class="form-label">Descrizione*</label>
                        <textarea class="form-control" id="descrizione" name="descrizione" required rows="3"></textarea>
                    </div>
                </div>

                <div class="text-center">
                    <button type="submit" class="btn btn-wedding btn-lg" onclick="return ValidateDate(this.form);">
                        <i class="fas fa-user-plus"></i> Registrati
                    </button>
                </div>
                
                <section class="py-4 bg-light">
                    <div class="container text-center">
                        <a href="login.php" class="text-decoration-none">Hai già un account? Accedi</a>
                    </div>
                </section>
            </form>
        </div>
    </div>
    <?php include 'includes/footer.php'; ?>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    <?php echo ValidateDate(); ?>
    </script>
</body>
</html> 