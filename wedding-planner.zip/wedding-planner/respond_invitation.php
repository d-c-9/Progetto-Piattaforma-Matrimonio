<?php
require_once 'config/config.php';
require_once 'includes/functions.php';
require_once 'includes/check_permissions.php';

// Verifica che l'utente sia loggato
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Verifica che l'utente sia un invitato attraverso la tabella PARTECIPAZIONE
$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT p.ID_Matrimonio 
                       FROM PARTECIPAZIONE p 
                       WHERE p.ID_Utente = ? AND p.ID_Ruolo = 3"); // 3 = Invitato
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header('Location: dashboard.php');
    exit();
}

$partecipazione = $result->fetch_assoc();
$wedding_id = $partecipazione['ID_Matrimonio'];


// Recupera i dettagli dell'invitato e del matrimonio
$stmt = $conn->prepare("SELECT i.*, m.data, m.location, m.descrizione 
                       FROM INVITATO i 
                       JOIN MATRIMONIO m ON i.ID_Matrimonio = m.ID_Matrimonio 
                       WHERE i.ID_Utente = ? AND i.ID_Matrimonio = ?");
$stmt->bind_param("ii", $user_id, $wedding_id);
$stmt->execute();
$invitato = $stmt->get_result()->fetch_assoc();

// Se non esiste un record nella tabella INVITATO viene creato
if (!$invitato) {
    // Recupera i dati dell'utente
    $stmt = $conn->prepare("SELECT username, email FROM UTENTE WHERE ID_Utente = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $user_data = $stmt->get_result()->fetch_assoc();
    
    // Inserisci il record nella tabella INVITATO
    $stmt = $conn->prepare("INSERT INTO INVITATO (nome, email, conferma, ID_Utente, ID_Matrimonio, ID_Categoria) 
                           VALUES (?, ?, 'in attesa', ?, ?, 2)"); // 2 = Amici come categoria default
    $stmt->bind_param("ssii", $user_data['username'], $user_data['email'], $user_id, $wedding_id);
    $stmt->execute();
    
    // Ricarica i dati dell'invitato
    $stmt = $conn->prepare("SELECT i.*, m.data, m.location, m.descrizione 
                           FROM INVITATO i 
                           JOIN MATRIMONIO m ON i.ID_Matrimonio = m.ID_Matrimonio 
                           WHERE i.ID_Utente = ? AND i.ID_Matrimonio = ?");
    $stmt->bind_param("ii", $user_id, $wedding_id);
    $stmt->execute();
    $invitato = $stmt->get_result()->fetch_assoc();
}

// Gestione della risposta all'invito
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['conferma'])) {
        try {
            // Inizia la transazione
            $conn->begin_transaction();
            
            $conferma = $_POST['conferma'];
            $nome = sanitizeInput($_POST['nome']);
            $cognome = sanitizeInput($_POST['cognome']);
            $telefono = sanitizeInput($_POST['telefono']);
            $categoria = (int)$_POST['categoria'];
            
            // Aggiorna i dati dell'invitato
            $stmt = $conn->prepare("UPDATE INVITATO 
                                  SET conferma = ?, nome = ?, cognome = ?, telefono = ?, ID_Categoria = ? 
                                  WHERE ID_Utente = ? AND ID_Matrimonio = ?");
            $stmt->bind_param("ssssiis", $conferma, $nome, $cognome, $telefono, $categoria, $user_id, $wedding_id);
            $stmt->execute();
            
            // Notifiche per coppia e wedding planner
            $stmt = $conn->prepare("SELECT u.ID_Utente 
                                  FROM UTENTE u 
                                  JOIN PARTECIPAZIONE p ON u.ID_Utente = p.ID_Utente 
                                  WHERE p.ID_Matrimonio = ? AND p.ID_Ruolo IN (1, 2)"); //  ruoli 1 e 2 per coppia e wedding planner
            $stmt->bind_param("i", $wedding_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            while ($destinatario = $result->fetch_assoc()) {
                $messaggio = "L'invitato " . $nome . " " . $cognome;
                
                switch($conferma) {
                    case 'confermato':
                        $messaggio .= " ha accettato l'invito al matrimonio";
                        break;
                    case 'rifiutato':
                        $messaggio .= " ha rifiutato l'invito al matrimonio";
                        break;
                    case 'in attesa':
                        $messaggio .= " ha impostato la sua risposta all'invito al matrimonio come 'in attesa di conferma'";
                        break;
                }
                
                $stmt = $conn->prepare("INSERT INTO NOTIFICA (messaggio, data_ora, stato, ID_Utente) 
                                      VALUES (?, NOW(), 'non_letto', ?)");
                $stmt->bind_param("si", $messaggio, $destinatario['ID_Utente']);
                $stmt->execute();
            }
            
            // Notifica per l'invitato
            $messaggio_invitato = "";
            switch($conferma) {
                case 'confermato':
                    $messaggio_invitato = "Hai confermato la tua presenza al matrimonio";
                    break;
                case 'rifiutato':
                    $messaggio_invitato = "Hai comunicato che non potrai partecipare al matrimonio";
                    break;
                case 'in attesa':
                    $messaggio_invitato = "La tua risposta all'invito è stata aggiornata come 'in attesa di conferma'";
                    break;
            }
            
            // Inserisci la notifica per l'invitato
            $stmt = $conn->prepare("INSERT INTO NOTIFICA (messaggio, data_ora, stato, ID_Utente) 
                                  VALUES (?, NOW(), 'non_letto', ?)");
            $stmt->bind_param("si", $messaggio_invitato, $user_id);
            $stmt->execute();
            
            // Commit della transazione
            $conn->commit();
            
            $_SESSION['success'] = "La tua risposta è stata registrata con successo";
            header('Location: respond_invitation.php');
            exit();
            
        } catch (Exception $e) {
            // Rollback in caso di errore
            $conn->rollback();
            $_SESSION['error'] = "Si è verificato un errore durante il salvataggio della risposta "; // . $e->getMessage();
        }
    }
}

$page_title = "Risposta all'Invito";
include 'includes/header.php';
?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">Risposta all'Invito</h4>
                    <a href="wedding_details.php" class="btn btn-primary">
                        <i class="fas fa-info-circle"></i> Dettagli Matrimonio
                    </a>
                </div>
                <div class="card-body">
                    <?php if (isset($_SESSION['success'])): ?>
                        <div class="alert alert-success">
                            <?php 
                            echo $_SESSION['success'];
                            unset($_SESSION['success']);
                            ?>
                        </div>
                    <?php endif; ?>

                    <?php if (isset($_SESSION['error'])): ?>
                        <div class="alert alert-danger">
                            <?php 
                            echo $_SESSION['error'];
                            unset($_SESSION['error']);
                            ?>
                        </div>
                    <?php endif; ?>
                    <form method="POST" class="mt-4">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="nome" class="form-label">Nome</label>
                                <input type="text" class="form-control" id="nome" name="nome" 
                                       value="<?php echo htmlspecialchars($invitato['nome'] ?? ''); ?>" required>
                            </div>
                            <div class="col-md-6">
                                <label for="cognome" class="form-label">Cognome</label>
                                <input type="text" class="form-control" id="cognome" name="cognome" 
                                       value="<?php echo htmlspecialchars($invitato['cognome'] ?? ''); ?>" required>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="telefono" class="form-label">Telefono</label>
                                <input type="tel" class="form-control" id="telefono" name="telefono" 
                                       value="<?php echo htmlspecialchars($invitato['telefono'] ?? ''); ?>">
                            </div>
                            <div class="col-md-6">
                                <label for="categoria" class="form-label">Categoria</label>
                                <select class="form-select" id="categoria" name="categoria" required>
                                    <?php
                                    $stmt = $conn->prepare("SELECT * FROM CATEGORIA ORDER BY nome DESC");
                                    $stmt->execute();
                                    $categorie = $stmt->get_result();
                                    while ($categoria = $categorie->fetch_assoc()):
                                    ?>
                                        <option value="<?php echo $categoria['ID_Categoria']; ?>" 
                                                <?php echo ($invitato['ID_Categoria'] ?? '') == $categoria['ID_Categoria'] ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($categoria['nome']); ?>
                                        </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                        </div>

                        <div class="mb-4">
                            <h5> La tua risposta all'invito:</h5>
                            <div class="d-flex gap-3">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="conferma" 
                                           id="conferma_si" value="confermato" 
                                           <?php echo ($invitato['conferma'] ?? '') == 'confermato' ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="conferma_si">
                                        Confermo la mia presenza
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="conferma" 
                                           id="conferma_no" value="rifiutato"
                                           <?php echo ($invitato['conferma'] ?? '') == 'rifiutato' ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="conferma_no">
                                        Non potrò partecipare
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="conferma" 
                                           id="conferma_forse" value="in attesa"
                                           <?php echo ($invitato['conferma'] ?? '') == 'in attesa' ? 'checked' : ''; ?>>
                                    <label class="form-check-label" for="conferma_forse">
                                        Devo ancora decidere
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="text-center">
                            <button type="submit" class="btn btn-primary">
                                Salva Risposta
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?> 